package com.trashclash.trashclash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrashclashApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrashclashApplication.class, args);
	}

}
